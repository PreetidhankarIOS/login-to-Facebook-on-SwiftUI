//
//  ContentView.swift
//  Facebook_Login_SwiftUI
//
//  Created by Ashish Viltoriya on 29/12/23.
//

import SwiftUI
import FacebookLogin

struct ContentView: View {
    var body: some View {

        VStack {
            
            Button(action: {
                UserLoginManager.instance.doLogin()
                if UserLoginManager.isLogin == true {
                    HomePage()
                }
                
            }){
                HStack(spacing: 15) {
                    Image("facebook")
                        .renderingMode(.original)
                        .resizable()
                        .frame(width: 25, height: 25)
                        .padding(.leading, 85)
                    Text("Sign in with Facebook")
                        .modifier(CustomTextM(fontName: "NunitoSans-Bold", fontSize: 16, fontColor: Color.white))
                    Spacer()
                }}
            
            .modifier(SFButton())
            .background(Color.blue)
            .cornerRadius(50.0)
            .padding(.bottom,0)
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

