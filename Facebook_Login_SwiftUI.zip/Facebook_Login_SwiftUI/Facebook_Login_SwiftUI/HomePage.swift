//
//  HomePage.swift
//  Facebook_Login_SwiftUI
//
//  Created by Ashish Viltoriya on 30/12/23.
//

import Foundation
import SwiftUI


import Foundation
import SwiftUI

struct HomePage: View {
    
        //MARK: - PROPERTIES
        
        var body: some View {
            
            ZStack{
                //  BG
                Text("Welcome Facebook")
                
            }
            
        }
    
}
