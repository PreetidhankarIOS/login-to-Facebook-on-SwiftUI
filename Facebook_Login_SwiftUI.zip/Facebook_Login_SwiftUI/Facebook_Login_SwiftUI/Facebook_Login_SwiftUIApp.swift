//
//  Facebook_Login_SwiftUIApp.swift
//  Facebook_Login_SwiftUI
//
//  Created by Ashish Viltoriya on 29/12/23.
//

import SwiftUI
import Foundation


@main
struct Facebook_Login_SwiftUIApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                
        }
    }
}
