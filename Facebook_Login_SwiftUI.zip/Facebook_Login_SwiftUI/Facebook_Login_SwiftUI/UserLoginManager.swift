//
//  UserLoginManager.swift
//  Facebook_Login_SwiftUI
//
//  Created by Ashish Viltoriya on 29/12/23.
//

import Foundation
import FacebookCore
import FacebookAEM
import SwiftUI
import FBSDKLoginKit

class UserLoginManager {
    
    static let instance = UserLoginManager()
    static var isLogin = false
    private init() {}
    
    func doLogin() {
        // Check current Login Status
        if let token = AccessToken.current, !token.isExpired {
            // User is logged in, do work such as go to next view controller.
        } else {
            let loginManager = LoginManager()
           // loginManager.logOut()
            loginManager.logIn(permissions: ["public_profile", "email"], from: nil) { result, error in
                
                if let error = error {
                    // Handle login error here
                    print("Error: \(error.localizedDescription)")
                } else if let result = result, !result.isCancelled {
                    // Login successful, you can access the user's Facebook data here
                    self.fetchFacebookUserData()
                } else {
                    // Login was canceled by the user
                    print("Login was cancelled.")
                }
                
            }
        }
    }
    
   // MARK: - Fetch Facebook User Data

          func fetchFacebookUserData() {
              if AccessToken.current != nil {
                  // You can make a Graph API request here to fetch user data
                  GraphRequest(graphPath: "me", parameters: ["fields": "id, name, email"]).start { (connection, result, error) in
                      if let error = error {
                          // Handle API request error here
                          print("Error: \(error.localizedDescription)")
                      } else if let userData = result as? [String: Any] {
                          // Access the user data here
                          let userID = userData["id"] as? String
                          let name = userData["name"] as? String
                          let email = userData["email"] as? String
                          // Handle the user data as needed
                          print("User ID: \(userID ?? "")")
                          print("Name: \(name ?? "")")
                          print("Email: \(email ?? "")")
                          UserLoginManager.isLogin = true
                      }
                          
                  }
              } else {
                  print("No active Facebook access token.")
              }
          }
    
    
}
